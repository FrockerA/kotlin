package com.example.photogalleryapp

data class Photo(
    val urls: Urls
)

data class Urls(
    val regular: String
)
